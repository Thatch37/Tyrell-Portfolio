// --- Job Application Tracker JS ---
const jobForm = document.getElementById('jobForm');
const jobList = document.getElementById('jobList');

// Load jobs from localStorage
function loadJobs() {
  const jobs = JSON.parse(localStorage.getItem('jobs')) || [];
  jobList.innerHTML = '';
  jobs.forEach((job, index) => {
    const li = document.createElement('li');
    li.className = 'list-group-item d-flex justify-content-between align-items-center';
    li.innerHTML = `
      <div>
        <strong>${job.title}</strong> at <em>${job.company}</em><br />
        Applied on: ${job.date}
      </div>
      <button class="btn btn-danger btn-sm">Delete</button>
    `;
    li.querySelector('button').addEventListener('click', () => {
      deleteJob(index);
    });
    jobList.appendChild(li);
  });
}

// Add job
jobForm.addEventListener('submit', e => {
  e.preventDefault();
  const title = document.getElementById('jobTitle').value.trim();
  const company = document.getElementById('companyName').value.trim();
  const date = document.getElementById('applicationDate').value;
  if (!title || !company || !date) return;

  const jobs = JSON.parse(localStorage.getItem('jobs')) || [];
  jobs.push({ title, company, date });
  localStorage.setItem('jobs', JSON.stringify(jobs));

  jobForm.reset();
  loadJobs();
});

// Delete job
function deleteJob(index) {
  const jobs = JSON.parse(localStorage.getItem('jobs')) || [];
  jobs.splice(index, 1);
  localStorage.setItem('jobs', JSON.stringify(jobs));
  loadJobs();
}

loadJobs();

// --- Weather App JS ---
const weatherForm = document.getElementById('weatherForm');
const weatherResult = document.getElementById('weatherResult');

weatherForm.addEventListener('submit', e => {
  e.preventDefault();
  const city = document.getElementById('cityInput').value.trim();
  if (!city) return;

  const apiKey = 'YOUR_OPENWEATHERMAP_API_KEY'; // Replace with your OpenWeatherMap API key
  const url = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&units=imperial&appid=${apiKey}`;

  weatherResult.innerHTML = 'Loading...';

  fetch(url)
    .then(response => {
      if (!response.ok) throw new Error('City not found');
      return response.json();
    })
    .then(data => {
      weatherResult.innerHTML = `
        <h6>${data.name}, ${data.sys.country}</h6>
        <p><strong>${data.weather[0].main}</strong> - ${data.weather[0].description}</p>
        <p>Temperature: ${data.main.temp} °F</p>
        <p>Humidity: ${data.main.humidity}%</p>
        <p>Wind Speed: ${data.wind.speed} mph</p>
      `;
    })
    .catch(() => {
      weatherResult.innerHTML = '<p class="text-danger">City not found. Please try again.</p>';
    });
});
