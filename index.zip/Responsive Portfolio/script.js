const toggleBtn = document.getElementById("themeToggle");
const html = document.documentElement;

toggleBtn.addEventListener("click", () => {
  const currentTheme = html.getAttribute("data-theme");
  const isDark = currentTheme === "dark";

  html.setAttribute("data-theme", isDark ? "light" : "dark");
  toggleBtn.innerHTML = isDark ? "🌙 Dark Mode" : "☀️ Light Mode";
});