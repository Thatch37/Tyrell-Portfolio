const form = document.getElementById('weather-form');
const cityInput = document.getElementById('city');
const resultDiv = document.getElementById('weather-result');

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const city = cityInput.value.trim();
  if (!city) {
    alert('Please enter a city name');
    return;
  }

  resultDiv.textContent = 'Loading...';

  try {
    // 1. Get lat/lon from city name using OpenStreetMap Nominatim
    const geoRes = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(city)}`);
    const geoData = await geoRes.json();
    if (!geoData.length) {
      resultDiv.textContent = 'City not found.';
      return;
    }

    const lat = geoData[0].lat;
    const lon = geoData[0].lon;

    // 2. Get forecast URL from NWS
    const pointRes = await fetch(`https://api.weather.gov/points/${lat},${lon}`);
    if (!pointRes.ok) throw new Error('Failed to get weather grid info.');
    const pointData = await pointRes.json();

    const forecastUrl = pointData.properties.forecast;

    // 3. Get forecast data
    const forecastRes = await fetch(forecastUrl);
    if (!forecastRes.ok) throw new Error('Failed to fetch forecast.');
    const forecastData = await forecastRes.json();

    const today = forecastData.properties.periods[0];

    // 4. Display result
    resultDiv.innerHTML = `
      <h2>Weather in ${geoData[0].display_name.split(',')[0]}</h2>
      <p><strong>${today.name}</strong>: ${today.shortForecast}</p>
      <p>Temperature: ${today.temperature} °${today.temperatureUnit}</p>
      <p>Wind: ${today.windSpeed} ${today.windDirection}</p>
    `;

  } catch (error) {
    console.error(error);
    resultDiv.textContent = 'Failed to load weather data.';
  }
});

