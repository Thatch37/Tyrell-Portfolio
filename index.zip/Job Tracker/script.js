const form = document.getElementById('job-form');
const applicationsList = document.getElementById('applications-list');

let applications = JSON.parse(localStorage.getItem('applications')) || [];

function saveApplications() {
  localStorage.setItem('applications', JSON.stringify(applications));
}

function renderApplications() {
  applicationsList.innerHTML = '';
  applications.forEach((app, index) => {
    const tr = document.createElement('tr');

    tr.innerHTML = `
      <td data-label="Company">${app.company}</td>
      <td data-label="Position">${app.position}</td>
      <td data-label="Status">${app.status}</td>
      <td data-label="Date Applied">${app.dateApplied}</td>
      <td data-label="Actions">
        <button class="edit-btn" data-index="${index}">Edit</button>
        <button class="delete-btn" data-index="${index}">Delete</button>
      </td>
    `;

    applicationsList.appendChild(tr);
  });
  attachListeners();
}

function attachListeners() {
  document.querySelectorAll('.edit-btn').forEach(button => {
    button.addEventListener('click', e => {
      const idx = e.target.dataset.index;
      editApplication(idx);
    });
  });

  document.querySelectorAll('.delete-btn').forEach(button => {
    button.addEventListener('click', e => {
      const idx = e.target.dataset.index;
      deleteApplication(idx);
    });
  });
}

function editApplication(index) {
  const app = applications[index];
  document.getElementById('company').value = app.company;
  document.getElementById('position').value = app.position;
  document.getElementById('status').value = app.status;
  document.getElementById('date-applied').value = app.dateApplied;

  // Remove the application to update on submit
  applications.splice(index, 1);
  saveApplications();
  renderApplications();
}

function deleteApplication(index) {
  if (confirm('Are you sure you want to delete this application?')) {
    applications.splice(index, 1);
    saveApplications();
    renderApplications();
  }
}

form.addEventListener('submit', e => {
  e.preventDefault();
  const company = document.getElementById('company').value.trim();
  const position = document.getElementById('position').value.trim();
  const status = document.getElementById('status').value;
  const dateApplied = document.getElementById('date-applied').value;

  if (!company || !position || !status || !dateApplied) {
    alert('Please fill out all fields');
    return;
  }

  applications.push({ company, position, status, dateApplied });
  saveApplications();
  renderApplications();
  form.reset();
});

renderApplications();
